package com.optioncare.auth.api.controller.setup;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.optioncare.auth.api.model.Role;
import com.optioncare.auth.api.service.PermissionService;
import com.optioncare.auth.api.service.RoleService;
import com.optioncare.common.model.Permission;
import com.optioncare.common.util.ControllerBase;

/**
 * Only for development
 */
@RestController
@RequestMapping("/roles-permissions-setup")
public class RolesPermissionsSetupController extends ControllerBase{

	@Autowired
	private PermissionService permissionService;
	
	@Autowired
	private RoleService roleService;
	
	@RequestMapping(value="/init", method=RequestMethod.POST)
	public ResponseEntity<String> init(){
		
		//Permission
		Permission permission_USER = new Permission();
		permission_USER.setCode(Permission.USER);
		permission_USER.setStatus(1);
		
		Permission permission_ADMIN = new Permission();
		permission_ADMIN.setCode(Permission.USER_ADMIN);
		permission_ADMIN.setStatus(1);
		

		permissionService.add(permission_USER);
		permissionService.add(permission_ADMIN);

		//Permission
		
		//Role ROLE_ADMIN
		Role role_ADMIN = new Role();
		role_ADMIN.setName(Role.ROLE_ADMIN);
		role_ADMIN.setStatus(1);
		role_ADMIN.getPermissions().add(permission_USER);
		role_ADMIN.getPermissions().add(permission_ADMIN);


		roleService.add(role_ADMIN);

		return makeResponse("roles-permissions : init");
		
	}
	
	
}
