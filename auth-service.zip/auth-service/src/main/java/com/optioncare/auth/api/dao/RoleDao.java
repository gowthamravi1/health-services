package com.optioncare.auth.api.dao;

import com.optioncare.auth.api.model.Role;
import com.optioncare.common.dao.GenericDao;

public interface RoleDao extends GenericDao<Role>{

}
