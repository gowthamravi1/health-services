package com.optioncare.auth.api.dao;

import java.util.List;

import com.optioncare.auth.api.model.User;
import com.optioncare.common.dao.GenericDao;
import com.optioncare.common.exception.DataAccessException;
import com.optioncare.common.model.Permission;

public interface UserDao extends GenericDao<User>{
	
	User findByEmail(String email) throws DataAccessException;

	List<Permission> findUserPermissions()throws DataAccessException;
	
	User findUserByToken(String token)throws DataAccessException;

	User findByUsernameOrEmail(String username, String email) throws DataAccessException;
	
}
