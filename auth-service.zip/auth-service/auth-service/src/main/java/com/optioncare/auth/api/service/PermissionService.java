package com.optioncare.auth.api.service;

import com.optioncare.common.model.Permission;
import com.optioncare.common.service.GenericService;

public interface PermissionService extends GenericService<Permission>{
}
