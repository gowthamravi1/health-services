package com.optioncare.auth.api.service;

import com.optioncare.auth.api.model.Role;
import com.optioncare.common.service.GenericService;

public interface RoleService extends GenericService<Role>{
}
