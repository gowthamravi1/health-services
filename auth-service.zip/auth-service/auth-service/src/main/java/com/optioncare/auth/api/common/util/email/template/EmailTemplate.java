package com.optioncare.auth.api.common.util.email.template;

public interface EmailTemplate {
	String getTextContent() throws Exception;
}
