package com.optioncare.auth.api.dao;

import com.optioncare.common.dao.GenericDao;
import com.optioncare.common.model.Permission;

public interface PermissionDao extends GenericDao<Permission>{

}
