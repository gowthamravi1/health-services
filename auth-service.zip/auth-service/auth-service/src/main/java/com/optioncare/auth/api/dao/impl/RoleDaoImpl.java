package com.optioncare.auth.api.dao.impl;

import com.optioncare.auth.api.model.Role;
import org.springframework.stereotype.Repository;

import com.optioncare.auth.api.dao.RoleDao;
import com.optioncare.common.dao.impl.GenericDaoImpl;

@Repository
public class RoleDaoImpl extends GenericDaoImpl<Role> implements RoleDao {

	public RoleDaoImpl() {
		super(Role.class);
	}
	
}
