package com.quebic.product.api.service;

import com.quebic.common.service.GenericService;
import com.quebic.product.api.model.Product;

public interface ProductService extends GenericService<Product>{
}
