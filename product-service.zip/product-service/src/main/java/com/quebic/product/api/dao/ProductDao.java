package com.quebic.product.api.dao;

import com.quebic.common.dao.GenericDao;
import com.quebic.product.api.model.Product;

public interface ProductDao extends GenericDao<Product> {

}
