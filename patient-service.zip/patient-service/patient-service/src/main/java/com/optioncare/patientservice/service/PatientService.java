package com.optioncare.patientservice.service;

import java.math.BigInteger;
import java.util.Optional;

import com.optioncare.common.service.GenericService;
import com.optioncare.patientservice.model.Patient;

import rx.Single;

public interface PatientService extends GenericService<Patient> {

    public Single<Optional<Patient>> findById(BigInteger id);
	
}
