package com.optioncare.patientservice.daoimpl;

import org.springframework.stereotype.Repository;

@Repository
public class PatientDaoImpl {

}
	