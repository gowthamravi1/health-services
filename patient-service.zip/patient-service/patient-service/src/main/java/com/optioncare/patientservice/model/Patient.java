package com.optioncare.patientservice.model;

import java.math.BigInteger;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "GROUP_USER")
public class Patient{
	@Id
	@Column(name = "Group_Id")
	private BigInteger GroupId;
	private BigInteger User_Id;
	public BigInteger getGroup_Id() {
		return GroupId;
	}
	public void setGroup_Id(BigInteger group_Id) {
		GroupId = group_Id;
	}
	public BigInteger getUser_Id() {
		return User_Id;
	}
	public void setUser_Id(BigInteger user_Id) {
		User_Id = user_Id;
	}

	
	
}
