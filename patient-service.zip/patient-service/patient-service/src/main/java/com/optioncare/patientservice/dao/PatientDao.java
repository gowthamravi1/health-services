package com.optioncare.patientservice.dao;

import java.math.BigInteger;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.optioncare.patientservice.model.Patient;

@Repository
public interface PatientDao extends JpaRepository<Patient, BigInteger> {

	@Query(value = "SELECT * FROM [INTEGRATION-1pm].[boards].[GROUP_USER] t where t.Group_Id =:id", nativeQuery = true)
	public Optional<Patient> findById(@Param("id") BigInteger id);
}