package com.optioncare.patientservice.controller;

import java.math.BigInteger;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.optioncare.common.async.response.AsyncResponseEntity;
import com.optioncare.common.util.ControllerBase;
import com.optioncare.patientservice.model.Patient;
import com.optioncare.patientservice.service.PatientService;

@RestController
@RequestMapping("search-patients")
public class PatientSearchController extends ControllerBase {
	@Autowired
	private PatientService patientService;

	@RequestMapping("/{id}")
	public AsyncResponseEntity<Optional<Patient>> getById(@PathVariable("id") BigInteger id) {
		return makeAsyncResponse(patientService.findById(id));

	}
}
