package com.optioncare.patientservice.serviceimpl;

import java.math.BigInteger;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.optioncare.common.exception.DataAccessException;
import com.optioncare.common.service.impl.GenericServiceImpl;
import com.optioncare.patientservice.dao.PatientDao;
import com.optioncare.patientservice.model.Patient;
import com.optioncare.patientservice.service.PatientService;

import rx.Single;

@Service
public class PatientServiceImpl extends GenericServiceImpl<Patient> implements PatientService{

	@Autowired
	private PatientDao patientDao;
	
//	@Override
//	public Optional<Patient> findById(BigInteger id) {
//		// TODO Auto-generated method stub
//		Optional<Patient> Patient1 = patientDao.findByGroupId(id);
//		return Patient1;
//	}
	
	@Override
	public Single<Optional<Patient>> findById(BigInteger id){
		try {
		return Single.just(patientDao.findById(id));
	}catch (Exception e) {
		return Single.error(e);
    }
	}
	
}

