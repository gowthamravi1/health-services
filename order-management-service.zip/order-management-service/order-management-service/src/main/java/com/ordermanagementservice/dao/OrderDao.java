package com.ordermanagementservice.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.ordermanagementservice.modal.OrderDetails;

@Repository
public interface OrderDao extends CrudRepository<OrderDetails, Integer> {

	OrderDetails findByOrderId(int orderId);
	
}
