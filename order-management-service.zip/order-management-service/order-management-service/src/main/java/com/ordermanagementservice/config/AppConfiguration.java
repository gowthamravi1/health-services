package com.ordermanagementservice.config;

import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.web.client.RestTemplate;

import com.optioncare.common.async.AsyncConfig;
import com.optioncare.common.cache.CacheConfig;
import com.optioncare.common.sse.SseConfig;

@Configuration
@Import({AsyncConfig.class, SseConfig.class, CacheConfig.class})
public class AppConfiguration {

    @LoadBalanced
    @Bean
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }

}
