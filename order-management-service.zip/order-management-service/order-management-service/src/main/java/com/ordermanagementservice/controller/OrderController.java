package com.ordermanagementservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.optioncare.common.async.response.AsyncResponseEntity;
import com.optioncare.common.util.ControllerBase;
import com.ordermanagementservice.modal.OrderDetails;
import com.ordermanagementservice.service.OrderService;

@RestController
@RequestMapping("order-service")
public class OrderController extends ControllerBase {
	
	@Autowired
	OrderService orderService;
	
	@PostMapping("/create-order")
	public AsyncResponseEntity<OrderDetails> createOrder(@RequestBody OrderDetails order) {
		return makeAsyncResponse(orderService.createOrder(order));
		
	}
	
	@GetMapping("/view-all-orders")
	public AsyncResponseEntity<List<OrderDetails>> viewOrders() {
		return makeAsyncResponse(orderService.viewOrders());
		
	}
	
	@GetMapping("/view-order/{orderId}")
	public AsyncResponseEntity<OrderDetails> viewOrderById(@PathVariable("orderId") int orderId) {
		return makeAsyncResponse(orderService.viewOrderById(orderId));
		
	}

}
