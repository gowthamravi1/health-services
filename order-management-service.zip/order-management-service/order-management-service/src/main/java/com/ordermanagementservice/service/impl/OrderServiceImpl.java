package com.ordermanagementservice.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.optioncare.common.service.impl.GenericServiceImpl;
import com.ordermanagementservice.dao.OrderDao;
import com.ordermanagementservice.modal.OrderDetails;
import com.ordermanagementservice.service.OrderService;

import rx.Single;

@Service
public class OrderServiceImpl extends GenericServiceImpl<OrderDetails> implements OrderService{

	@Autowired
	OrderDao orderDao;
	
	@Override
	public Single<OrderDetails> createOrder(OrderDetails order) {
		
		return Single.just(orderDao.save(order));
	}

	@Override
	public Single<List<OrderDetails>> viewOrders() {
		
		return Single.just((List<OrderDetails>) orderDao.findAll());
	}

	@Override
	public Single<OrderDetails> viewOrderById(int orderId) {
		return Single.just(orderDao.findByOrderId(orderId));
	}
	
	

}
