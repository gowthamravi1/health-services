package com.ordermanagementservice.service;

import java.util.List;

import com.optioncare.common.service.GenericService;
import com.ordermanagementservice.modal.OrderDetails;

import rx.Single;

public interface OrderService extends GenericService<OrderDetails> {
	
	
	public Single<OrderDetails> createOrder(OrderDetails order);

	public Single<List<OrderDetails>> viewOrders();

	public Single<OrderDetails> viewOrderById(int orderId);

}
