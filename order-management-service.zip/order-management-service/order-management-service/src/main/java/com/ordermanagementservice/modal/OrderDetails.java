package com.ordermanagementservice.modal;

import java.util.Date;
import java.util.Map;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="OrderDetails")
public class OrderDetails {
	@Id
	private int orderId;
	
	private String patientName;
	
	private String drugName;
	
	private Date orderedDate;

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public String getpatientName() {
		return patientName;
	}

	public void setpatientName(String patientName) {
		this.patientName = patientName;
	}

	public String getDrugName() {
		return drugName;
	}

	public void setDrugName(String drugName) {
		this.drugName = drugName;
	}

	public Date getOrderedDate() {
		return orderedDate;
	}

	public void setOrderedDate(Date orderedDate) {
		this.orderedDate = orderedDate;
	}

	public OrderDetails(int orderId, String patientName, String drugName, Date orderedDate) {
		super();
		this.orderId = orderId;
		this.patientName = patientName;
		this.drugName = drugName;
		this.orderedDate = orderedDate;
	}

	public OrderDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	

}
