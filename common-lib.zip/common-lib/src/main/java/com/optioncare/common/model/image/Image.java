package com.optioncare.common.model.image;

public class Image {

	private String fileName;
	
	public Image() {
	}
	
	
	
	public Image(String fileName) {
		this.fileName = fileName;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	
}
