package com.optioncare.common.messages;

public class InfoMessage {
	public static final String USER_PROFILE_IMAGE_SAVED = "USER_PROFILE_IMAGE_SAVED : {}";
	public static final String USER_COVER_IMAGE_SAVED = "USER_PROFILE_IMAGE_SAVED : {}";
	public static final String VEHICLE_IMAGE_SAVED = "VEHICLE_IMAGE_SAVED : {}";
}
