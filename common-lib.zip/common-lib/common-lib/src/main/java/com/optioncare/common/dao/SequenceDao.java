package com.optioncare.common.dao;

import com.optioncare.common.exception.DataAccessException;
import com.optioncare.common.model.Sequence;

public interface SequenceDao  extends GenericDao<Sequence>{

	int getNextSequenceId(String key) throws DataAccessException;
}
