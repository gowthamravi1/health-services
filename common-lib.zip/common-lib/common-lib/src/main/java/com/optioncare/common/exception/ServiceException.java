package com.optioncare.common.exception;

public class ServiceException extends Exception {

    /**
	 * 
	 */
	private static final long serialVersionUID = -6790978749789863233L;

	public ServiceException(String message) {
        super(message);
    }

}